cat /flag.txt >o
