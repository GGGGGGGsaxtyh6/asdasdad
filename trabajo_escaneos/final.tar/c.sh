cat flag.txt
